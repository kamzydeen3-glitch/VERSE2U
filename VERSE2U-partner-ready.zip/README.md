# VERSE2U Partner Ready
Mobile-first lyrics workspace with a provider-neutral distribution queue.
Direct Spotify/Apple lyrics publishing is only activated after approved provider/platform access is obtained. Never place Supabase secret/service_role keys in frontend files.
Setup: copy config.example.js to config.js, add your Supabase Project URL and publishable key, then host the folder on Vercel/Netlify/GitHub Pages. Server functions can be deployed to Supabase when needed.